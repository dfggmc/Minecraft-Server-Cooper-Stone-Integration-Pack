--
-- cPlayers:setSpawnPosition()
--
-------------------------------------------------------------------------------

function cPlayers:setSpawnPosition(aPosition)

  self.spawnPosition = aPosition;

end
-------------------------------------------------------------------------------

