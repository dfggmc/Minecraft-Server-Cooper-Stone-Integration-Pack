--Warps--
change_gm_when_changing_world = true

--Jails--
IsChatEnabled = false
AreCommandsEnabled = false
IsDiggingEnabled = true
IsPlaceEnabled = true
