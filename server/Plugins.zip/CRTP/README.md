# CRTP
Random teleportation for cuberite

### Permissions: 
- `crtp.tp` 

### Commands:  
- `/rtp` - teleport yourself into random coordinates `[X: -5000;5000 | Y: 0;70 | Z: -5000;5000]`

### WARNING:
This plugin possibly can increase RAM uses because of chunks loading.
