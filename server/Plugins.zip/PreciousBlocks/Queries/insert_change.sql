INSERT INTO @tablename 
(x, y, z, blocktype, blockmeta, cause, action, time)
VALUES
($x, $y, $z, $blocktype, $blockmeta, $cause, $action, $time)