CREATE TABLE IF NOT EXISTS @tablename (
	`x`         INTEGER,
	`y`         INTEGER,
	`z`         INTEGER,
	`blocktype` INTEGER,
	`blockmeta` INTEGER,
	`cause`     TEXT,
	`action`    TEXT,
	`time`      INTEGER
)