This plugin allows admins to see who or what placed a block, and revert it if needed. 

# Commands

### General
| Command | Permission | Description |
| ------- | ---------- | ----------- |
|/pb inspect | preciousblocks.inspect | Inspect who changed certain blocks|
|/pb revert | preciousblocks.reverse | Revert an area around you|



# Permissions
| Permissions | Description | Commands | Recommended groups |
| ----------- | ----------- | -------- | ------------------ |
| preciousblocks.inspect |  | `/pb inspect` |  |
| preciousblocks.reverse |  | `/pb revert` |  |
