SELECT * FROM @tablename
WHERE `x` = $x
AND `y` = $y
AND `z` = $z