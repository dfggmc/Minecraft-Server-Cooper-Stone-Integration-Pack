This is a plugin for [Cuberite](http://cuberite.org) that allows admins to see per-plugin memory usage.

The plugin provides a console command for listing the current values, and a webadmin page with history graphs. 	
