--
-- cPlayers:getLastMsgToPlayerTime()
--
-------------------------------------------------------------------------------

function cPlayers:getLastMsgToPlayerTime()

  return self.lastMsgToPlayerTime;

end
-------------------------------------------------------------------------------

