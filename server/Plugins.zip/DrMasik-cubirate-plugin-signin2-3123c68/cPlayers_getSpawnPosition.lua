--
-- cPlayers:getSpawnPosition()
--
-------------------------------------------------------------------------------

function cPlayers:getSpawnPosition()

  return self.spawnPosition;

end
-------------------------------------------------------------------------------

